for i in range(10):
    print(i)
    print(i*10)